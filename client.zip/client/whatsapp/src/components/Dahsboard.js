import React from 'react'
import SideBar from './sideBar'
import {Nav,Tab} from 'react-bootstrap'
import OpenConversation from './OpenConversation'
import { useConversation } from '../context/ConversationProvider'

export default function Dahsboard({id}) {
    const  {selectedConversation}=useConversation();

  return (
    <div>
    <div className='d-flex' style={{height:'100vh'}}>
      <SideBar id={id}></SideBar>
      {selectedConversation && <OpenConversation/>}
      </div>
    </div>
  )
}
