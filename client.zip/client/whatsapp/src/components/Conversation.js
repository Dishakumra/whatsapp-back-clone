import React from 'react';
import { ListGroup } from 'react-bootstrap';
import { useConversation } from '../context/ConversationProvider'

export default function Conversation() {
    const {conversation,selectConversationIndex}=useConversation();
  return (
    <ListGroup variant="flush">
     {conversation.map((conversation,index)=>{
        return(
        <ListGroup.Item  
        key={index} 
        action 
        active={conversation.selected}
        onClick={()=> selectConversationIndex(index)}
         >
            {conversation.recipients.map(r=>r.name).join(',')}
        </ListGroup.Item>)
     })}
    </ListGroup>
  )
}
