import React, { useRef } from 'react'
import {Button, Container, Form} from 'react-bootstrap'
import {v4 as uuidV4} from 'uuid'

export default function Login({onIdSubmit}) {
const idRef=useRef();
const handleOnSubmit=(e)=>{
    e.preventDefault()
    onIdSubmit(idRef.current.value)


}

const createNewId=()=>{
    onIdSubmit(uuidV4())
}
  return (
   <Container className='align-items-center d-flex' style={{height:'100vh'}}>
    <Form className='w-100' onSubmit={handleOnSubmit}>
    <Form.Group>
        <Form.Label> Enter your id</Form.Label>
        <Form.Control type="text" ref={idRef} required className='mb-4'/>

       
    </Form.Group>
    <Button type="submit" className = "mr-2" style={{margin:'4px'}}> login</Button>
    <Button variant='secondary' className='ml-4' onClick={createNewId}>create A New Id</Button>

    </Form>
   </Container>
 
  )
}
