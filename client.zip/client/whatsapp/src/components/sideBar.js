import React, { useState } from 'react'
import { Button, Modal, Nav, Tab, TabContainer } from 'react-bootstrap'
import Contacts from './Contacts';
import Conversation from './Conversation';
import NewContactModal from './NewContactModal';
import NewConversationModal from './NewConversationModal';

const CONVERSATION_KEY='conversations';
const CONTACT_KEY='contact'

export default function ({id}) {
    const [activeKey,setActiveKey]=useState(CONVERSATION_KEY);
    const [isModalOpen,setIsModalOpen]=useState(false);
    const isConversationOpen=activeKey==CONVERSATION_KEY;

    const closeModal=()=>{
        setIsModalOpen(false);
    }

    const openModal=()=>{
        setIsModalOpen(true);
    }

  return (
    <div style={{width:'250px'}} className="d-flex flex-column">
     <TabContainer activeKey={activeKey} onSelect={setActiveKey}>
        <Nav variant='tabs' className="justify-content-center">
            <Nav.Item>
                <Nav.Link eventKey={CONVERSATION_KEY}> Conversation</Nav.Link>

            </Nav.Item>
            <Nav.Item>
                <Nav.Link eventKey={CONTACT_KEY}>Contacts</Nav.Link>

            </Nav.Item>
        </Nav>
        <Tab.Content className='border-right border-1 overflow-auto flex-grow-1' style={{borderRight:'1px solid #e8dbdb'}}>
            <Tab.Pane eventKey={CONVERSATION_KEY}>
                <Conversation/>

            </Tab.Pane>
            <Tab.Pane eventKey={CONTACT_KEY}>
                <Contacts/>

            </Tab.Pane>
        </Tab.Content>
        <div className='p-2  border-top ' style={{borderRight:'1px solid #e8dbdb',fontSize:'12px'}}>
            Your Id:<span className='text-muted'>{id}</span>
        </div>
        <Button className='rounded-0' onClick={openModal}>
            New {isConversationOpen ? "Conversation":"Contact"}
        </Button>

     </TabContainer>
     <Modal show={isModalOpen} onHide={closeModal}>
        {isConversationOpen?<NewConversationModal closeModal={closeModal}/>:<NewContactModal closeModal={closeModal}/>}
     </Modal>
    </div>
  )
}
