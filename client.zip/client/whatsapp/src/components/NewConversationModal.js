import React, { useState } from 'react';
import { Modal ,Form, Button, FormGroup} from 'react-bootstrap'
import {useConversation} from '../context/ConversationProvider';
import { useContacts } from '../context/ContactsProvider';

export default function NewConversationModal({closeModal}) {
    const [selectedContacts,setSelectedContacts]=useState([]);
    const {createConversation}=useConversation();
    const {contacts}=useContacts();

    const handleCheckBoxChange=(id)=>{
        setSelectedContacts(prevContactsId=>{
            if(prevContactsId.includes(id))
            {
                return prevContactsId.filter(prevId => prevId!==id)
            }
            else
            return [...prevContactsId,id]

        })

    }

    const handleOnSubmit=(e)=>{
        e.preventDefault();
        createConversation(selectedContacts);
        closeModal()

    }
  return (
    <>
    <Modal.Header closeButton={closeModal}>
        Create Conversation
    </Modal.Header>
    <Modal.Body>
        <Form onSubmit={handleOnSubmit}>
            {contacts.map(contact=>(
                <FormGroup controlId={contact.id} key={contact.id}>
                    <Form.Check
                    type='checkbox'
                    value={selectedContacts.includes(contact.id)}
                    label={contact.name}
                    onChange={()=> handleCheckBoxChange(contact.id)}

                    />
                </FormGroup>

            ))}
            <Button type='submit' className='mt-4'>Create</Button>
        </Form>

    </Modal.Body>
    </>
  )
}
