import { useState } from "react";
import { ContactsProvider } from "../context/ContactsProvider";
import { SocketProvider } from "../context/SocketProvider";
import ConversationProvider from "../context/ConversationProvider";
import useLocalStorage from "../hooks/useLocalStorage";
import Dahsboard from "./Dahsboard";
import Login from "./Login";

function App() {
  const[id,setId]=useLocalStorage('id');
  const dashboard=(
    <SocketProvider id={id}>
      <ContactsProvider>
        <ConversationProvider id={id}>
          <Dahsboard id={id}/>
        </ConversationProvider>
      </ContactsProvider>
    </SocketProvider>
    )
 return (
  <>
  {id?
  dashboard:
   <Login onIdSubmit={setId}></Login>}
   </>
  );
}

export default App;
