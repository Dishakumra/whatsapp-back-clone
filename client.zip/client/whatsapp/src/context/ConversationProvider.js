import React ,{ useCallback, useContext, useEffect, useState }from 'react'
import {useContacts} from '../context/ContactsProvider';
import useLocalStorage from '../hooks/useLocalStorage';
import { useSocket } from './SocketProvider';

const ConversationContext=React.createContext();


export function useConversation(){
    return useContext(ConversationContext);
  }


export default function ConversationProvider({id,children}) {
    const {contacts}=useContacts();
    const [conversation,setConversation]=useLocalStorage('conversation',[]);
    const [selectedConversationIndex,setSelectedConversationIndex]=useState(0);
    const socket=useSocket();

    const addMessageToConversation=useCallback(({recipients,text,sender})=>{
        setConversation(prevConversation=>{
            let madeChange=false;
            const newMessage={sender,text}
            const newConversation=prevConversation.map((convo)=>{
                if(arrayIsEqual(convo.recipients,recipients)){
                    madeChange=true;
                    return {...convo,messages:[...convo.messages,newMessage]}
                }
                return convo;
            })

            if(madeChange){
                return newConversation;

            }
            else{
                return [...prevConversation,{recipients,messages:[newMessage]}]

            }
        })

    },[setConversation])


    useEffect(()=>{
        if(socket==null) return ;
        socket.on('recieve-message',addMessageToConversation)

        return ()=> socket.off('recieve-message')
    },[socket,addMessageToConversation])

    const createConversation=(recipients)=>{
        setConversation(prevConversation=>
            [...prevConversation,{recipients,messages:[]}]
        )
    }

  

    const sendMessage=(recipients,text)=>{
        socket.emit('send-message',{recipients,text})
        addMessageToConversation({recipients,text,sender:id})
    }

    const formattedConversations=conversation.map((conversation,index)=>{
        const recipients=conversation.recipients.map((recip)=>{
            const contact=contacts.filter((contact)=>{
                { if(contact.id == recip)
                    return contact;
                   }
            }
            )
            const name=(contact && contact[0].name)|| recip
            return{id:recip,name}
        })
        const selected = index === selectedConversationIndex

        const messages=conversation.messages.map((message)=>{
            const contact=contacts.filter((contact)=>
                { if(contact.id == message.sender)
                 return contact;
                }
            
            )
            const name=(contact && contact[0].name)|| message.sender;
            const fromMe=id==message.sender;

            return {...message,senderName:name,fromMe}

        })
        return {...conversation,messages,recipients,selected}
    })

    const value={
        conversation:formattedConversations,
        selectedConversation:formattedConversations[selectedConversationIndex],
        sendMessage,
        selectConversationIndex:setSelectedConversationIndex,
        createConversation
    }

  return (
   <ConversationContext.Provider value={value}>
    {children}
   </ConversationContext.Provider>
  )
}
const arrayIsEqual=(a,b)=>{
    if(a.length!== b.length)
    return false;
    a.sort();
    b.sort();
    return a.every((element,index)=> element === b[index])

}
